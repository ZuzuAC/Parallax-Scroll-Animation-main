# Parallax-Scroll-Animation | Jerson Mejía

I will to use modern HTML, CSS, and JavaScript to create a completely responsive Parallax Scroll animation. We'll be using CSS transitions and animations for some cool animation effects.

# Screenshots

Here we have project screenshot, because isn´t posible upload the video to watching.

![Parallax-scroll-animation 1](https://github.com/Jersonwm/Parallax-Scroll-Animation/assets/9126710/f3553955-282c-4faa-9238-d2b928ce2dee)

![Parallax-scroll-animation 2](https://github.com/Jersonwm/Parallax-Scroll-Animation/assets/9126710/394c8842-e550-466d-a7a9-38a94806fab6)

![Parallax-scroll-animation 3](https://github.com/Jersonwm/Parallax-Scroll-Animation/assets/9126710/512a2b2a-1e23-40ef-bb80-6b6a550ee618)
